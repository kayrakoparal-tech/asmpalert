package com.asmp.dramaticalerts.listener;

import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.util.AmountParser;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.text.Text;

import java.util.Locale;

public class AlertCommand {
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, CommandRegistryAccess registryAccess) {
        dispatcher.register(
                ClientCommandManager.literal("asmpalert")
                        .then(ClientCommandManager.literal("clear")
                                .executes(ctx -> {
                                    AlertManager.clearQueue();
                                    ctx.getSource().sendFeedback(Text.literal("§a[ASMP Alerts] §fEfekt kuyruğu temizlendi."));
                                    return 1;
                                }))
                        .then(ClientCommandManager.literal("reload")
                                .executes(ctx -> {
                                    ConfigManager.load();
                                    ChatListener.reloadPatterns();
                                    ctx.getSource().sendFeedback(Text.literal("§a[ASMP Alerts] §fAyarlar ve regex desenleri yeniden yüklendi."));
                                    return 1;
                                }))
                        .then(ClientCommandManager.argument("player", StringArgumentType.word())
                                .then(ClientCommandManager.argument("amount", StringArgumentType.greedyString())
                                        .executes(ctx -> {
                                            String player = StringArgumentType.getString(ctx, "player");
                                            String rawAmount = StringArgumentType.getString(ctx, "amount").trim();

                                            AmountParser.AlertTier forcedTier = null;
                                            String amountToken = rawAmount;

                                            String[] tokens = rawAmount.split("\\s+");
                                            if (tokens.length >= 2) {
                                                AmountParser.AlertTier maybeTier = parseTierKeyword(tokens[tokens.length - 1]);
                                                if (maybeTier != null) {
                                                    forcedTier = maybeTier;
                                                    amountToken = rawAmount.substring(0, rawAmount.lastIndexOf(tokens[tokens.length - 1])).trim();
                                                }
                                            }

                                            double amount = AmountParser.parseAmount(amountToken);
                                            if (amount <= 0.0) {
                                                ctx.getSource().sendError(Text.literal("§cGeçersiz miktar! Örnek: §e1M, 10M, 100M, 1B, 60B"));
                                                return 0;
                                            }

                                            if (forcedTier != null) {
                                                AlertManager.enqueueWithTier(player, amount, forcedTier);
                                            } else {
                                                AlertManager.enqueue(player, amount);
                                            }

                                            ctx.getSource().sendFeedback(Text.literal(
                                                    "§6[ASMP Alerts] §fTetiklendi: §e" + player + " §7-> §a" + AmountParser.formatCompactAmount(amount)
                                            ));
                                            return 1;
                                        })))
        );
    }

    private static AmountParser.AlertTier parseTierKeyword(String keyword) {
        if (keyword == null) return null;
        return switch (keyword.toUpperCase(Locale.ROOT)) {
            case "TIER1", "1M", "HIGHROLLER" -> AmountParser.AlertTier.TIER_1_1M;
            case "TIER2", "10M", "MEGADROP" -> AmountParser.AlertTier.TIER_2_10M;
            case "TIER3", "100M", "MYTHIC" -> AmountParser.AlertTier.TIER_3_100M;
            case "TIER4", "1B", "GODLIKE" -> AmountParser.AlertTier.TIER_4_1B;
            case "TIER5", "10B", "60B", "ASTRONOMICAL", "LEGENDARY" -> AmountParser.AlertTier.TIER_5_10B_PLUS;
            default -> null;
        };
    }
}

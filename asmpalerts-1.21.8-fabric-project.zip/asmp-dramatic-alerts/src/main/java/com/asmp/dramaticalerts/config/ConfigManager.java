package com.asmp.dramaticalerts.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("asmpalerts.json");

    private static ModConfig config;

    public static class ModConfig {
        public boolean enabled = true;
        public String targetPlayerName = "Xhantos";
        public double minimumTriggerAmount = 1_000_000.0;

        public double tier1Min = 1_000_000.0;
        public double tier2Min = 10_000_000.0;
        public double tier3Min = 100_000_000.0;
        public double tier4Min = 1_000_000_000.0;
        public double tier5Min = 10_000_000_000.0;

        public float soundVolume = 1.0f;
        public boolean enableScreenShake = true;
        public float shakeIntensity = 1.0f;
        public float particleMultiplier = 1.0f;

        public List<String> chatRegexPatterns = new ArrayList<>(List.of(
                "(?i)(.+?)\\s+(?:sent|paid|donated|gave)\\s+(?:you|Xhantos)\\s+\\$?([0-9.,]+[KkMmBbTt]?)",
                "(?i)(.+?)\\s+sana\\s+\\$?([0-9.,]+[KkMmBbTt]?)\\s+(?:gönderdi|ödedi|bağışladı)"
        ));
    }

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
                ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
                config = loaded != null ? loaded : new ModConfig();
            } catch (IOException e) {
                config = new ModConfig();
            }
        } else {
            config = new ModConfig();
            save();
        }
        sanitize();
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(config, writer);
            }
        } catch (IOException ignored) {
        }
    }

    private static void sanitize() {
        if (config.targetPlayerName == null || config.targetPlayerName.isBlank()) {
            config.targetPlayerName = "Xhantos";
        }
        if (config.chatRegexPatterns == null) {
            config.chatRegexPatterns = new ArrayList<>();
        }
        config.soundVolume = Math.max(0.0f, Math.min(2.0f, config.soundVolume));
        config.shakeIntensity = Math.max(0.0f, Math.min(3.0f, config.shakeIntensity));
        config.particleMultiplier = Math.max(0.25f, Math.min(3.0f, config.particleMultiplier));
    }

    public static ModConfig get() {
        if (config == null) {
            load();
        }
        return config;
    }
}

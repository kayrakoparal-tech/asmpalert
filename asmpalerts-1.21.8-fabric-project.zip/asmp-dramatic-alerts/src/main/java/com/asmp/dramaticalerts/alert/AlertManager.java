package com.asmp.dramaticalerts.alert;

import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.render.AlertHudRenderer;
import com.asmp.dramaticalerts.util.AmountParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayDeque;
import java.util.Deque;

public class AlertManager {
    private static final Deque<AlertData> QUEUE = new ArrayDeque<>();
    private static AlertData currentAlert = null;
    private static float currentElapsedSeconds = 0.0f;
    private static long lastUpdateNanos = 0L;

    private static boolean playedFireworkStage = false;
    private static boolean playedMeteorStage = false;
    private static boolean playedChimeStage = false;
    private static long lastTickSoundNanos = 0L;

    public static void enqueue(String senderName, double amount) {
        if (amount <= 0.0) {
            return;
        }
        AmountParser.AlertTier tier = AmountParser.resolveTier(amount);
        enqueueWithTier(senderName, amount, tier);
    }

    public static void enqueueWithTier(String senderName, double amount, AmountParser.AlertTier tier) {
        ConfigManager.ModConfig cfg = ConfigManager.get();
        if (!cfg.enabled) {
            return;
        }
        AmountParser.AlertTier resolvedTier = tier != null ? tier : AmountParser.resolveTier(amount);
        float duration = resolvedTier.defaultDurationSeconds;
        if (amount >= 50_000_000_000.0) {
            duration = Math.max(duration, 7.6f);
        }

        AlertData data = new AlertData(senderName, amount, resolvedTier, duration);
        QUEUE.addLast(data);
    }

    public static void clearQueue() {
        QUEUE.clear();
        currentAlert = null;
        currentElapsedSeconds = 0.0f;
        AlertHudRenderer.resetEffects();
    }

    public static void tick() {
        long now = System.nanoTime();
        if (lastUpdateNanos == 0L) {
            lastUpdateNanos = now;
            return;
        }

        float dt = (now - lastUpdateNanos) / 1_000_000_000.0f;
        lastUpdateNanos = now;
        if (dt <= 0.0f) {
            return;
        }
        if (dt > 0.1f) {
            dt = 0.1f;
        }

        if (currentAlert == null) {
            if (!QUEUE.isEmpty()) {
                startAlert(QUEUE.pollFirst());
            } else {
                AlertHudRenderer.updateAmbientParticles(dt);
                return;
            }
        }

        currentElapsedSeconds += dt;
        processTimedSounds(currentAlert, currentElapsedSeconds, now);
        AlertHudRenderer.updateActiveAlert(currentAlert, currentElapsedSeconds, dt);

        if (currentElapsedSeconds >= currentAlert.durationSeconds) {
            currentAlert = null;
            currentElapsedSeconds = 0.0f;
        }
    }

    private static void startAlert(AlertData alert) {
        currentAlert = alert;
        currentElapsedSeconds = 0.0f;
        playedFireworkStage = false;
        playedMeteorStage = false;
        playedChimeStage = false;
        lastTickSoundNanos = 0L;

        ConfigManager.ModConfig cfg = ConfigManager.get();
        float vol = cfg.soundVolume;

        if (vol > 0.0f) {
            playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, vol * 0.85f, 0.72f);
            if (alert.tier.level >= 2) {
                playSound(SoundEvents.BLOCK_END_PORTAL_SPAWN, vol * 0.65f, 0.65f);
            }
            if (alert.tier.level >= 4) {
                playSound(SoundEvents.BLOCK_BEACON_ACTIVATE, vol * 0.8f, 0.95f);
            }
        }

        AlertHudRenderer.triggerInitialBurst(alert);
    }

    private static void processTimedSounds(AlertData alert, float elapsed, long nowNanos) {
        float vol = ConfigManager.get().soundVolume;
        if (vol <= 0.0f) {
            return;
        }

        if (elapsed < 0.85f && nowNanos - lastTickSoundNanos > 75_000_000L) {
            lastTickSoundNanos = nowNanos;
            float pitchProgress = elapsed / 0.85f;
            playSound(SoundEvents.UI_BUTTON_CLICK.value(), vol * 0.22f, 1.0f + pitchProgress * 0.55f);
        }

        if (!playedFireworkStage && elapsed >= 0.22f) {
            playedFireworkStage = true;
            playSound(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, vol * 0.8f, 1.05f);
            playSound(SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, vol * 0.95f, 0.9f);
        }

        if (!playedMeteorStage && alert.tier.level >= 2 && elapsed >= 0.52f) {
            playedMeteorStage = true;
            playSound(SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, vol * 0.9f, 0.8f);
            if (alert.tier.level >= 4) {
                playSound(SoundEvents.ENTITY_GENERIC_EXPLODE.value(), vol * 0.75f, 0.7f);
            }
        }

        if (!playedChimeStage && alert.tier.level >= 3 && elapsed >= 0.85f) {
            playedChimeStage = true;
            playSound(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, vol * 0.95f, 1.15f);
            playSound(SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, vol * 0.85f, 1.25f);
        }
    }

    private static void playSound(SoundEvent soundEvent, float volume, float pitch) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || volume <= 0.0f) {
            return;
        }
        client.getSoundManager().play(PositionedSoundInstance.master(soundEvent, pitch, volume));
    }

    public static AlertData getCurrentAlert() {
        return currentAlert;
    }

    public static float getCurrentElapsedSeconds() {
        return currentElapsedSeconds;
    }

    public static int getQueueSize() {
        return QUEUE.size();
    }
}

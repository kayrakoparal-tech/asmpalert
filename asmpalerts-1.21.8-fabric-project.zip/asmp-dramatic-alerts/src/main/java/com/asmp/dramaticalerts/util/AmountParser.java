package com.asmp.dramaticalerts.util;

import com.asmp.dramaticalerts.config.ConfigManager;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class AmountParser {
    private static final Pattern AMOUNT_PATTERN = Pattern.compile("^\\$?\\s*([0-9][0-9.,]*)\\s*([KkMmBbTt])?$");

    private AmountParser() {
    }

    public enum AlertTier {
        TIER_1_1M(1, "HIGH ROLLER", "§e§l★ 1M+ HIGH ROLLER ★", 5.5f),
        TIER_2_10M(2, "MEGA DROP", "§6§l☄ 10M+ MEGA DROP ☄", 5.8f),
        TIER_3_100M(3, "MYTHIC", "§d§l✦ 100M+ MYTHIC EVENT ✦", 6.2f),
        TIER_4_1B(4, "GODLIKE", "§c§l⚡ 1B+ GODLIKE DROP ⚡", 6.6f),
        TIER_5_10B_PLUS(5, "ASTRONOMICAL", "§6§l👑 10B+ LEGENDARY EVENT 👑", 7.2f);

        public final int level;
        public final String label;
        public final String badgeText;
        public final float defaultDurationSeconds;

        AlertTier(int level, String label, String badgeText, float defaultDurationSeconds) {
            this.level = level;
            this.label = label;
            this.badgeText = badgeText;
            this.defaultDurationSeconds = defaultDurationSeconds;
        }
    }

    public static double parseAmount(String rawAmount) {
        if (rawAmount == null || rawAmount.isBlank()) {
            return -1.0;
        }

        Matcher matcher = AMOUNT_PATTERN.matcher(rawAmount.trim());
        if (!matcher.matches()) {
            return -1.0;
        }

        String numPart = matcher.group(1);
        String suffix = matcher.group(2);

        double multiplier = 1.0;
        if (suffix != null && !suffix.isEmpty()) {
            switch (suffix.toUpperCase(Locale.ROOT)) {
                case "K" -> multiplier = 1_000.0;
                case "M" -> multiplier = 1_000_000.0;
                case "B" -> multiplier = 1_000_000_000.0;
                case "T" -> multiplier = 1_000_000_000_000.0;
                default -> {
                }
            }
        }

        String normalized = normalizeNumberString(numPart, suffix != null);
        try {
            double baseValue = Double.parseDouble(normalized);
            if (Double.isNaN(baseValue) || Double.isInfinite(baseValue) || baseValue <= 0.0) {
                return -1.0;
            }
            return baseValue * multiplier;
        } catch (NumberFormatException e) {
            return -1.0;
        }
    }

    private static String normalizeNumberString(String raw, boolean hasSuffix) {
        boolean hasDot = raw.indexOf('.') >= 0;
        boolean hasComma = raw.indexOf(',') >= 0;

        if (hasDot && hasComma) {
            int lastDot = raw.lastIndexOf('.');
            int lastComma = raw.lastIndexOf(',');
            if (lastDot > lastComma) {
                return raw.replace(",", "");
            } else {
                return raw.replace(".", "").replace(',', '.');
            }
        }

        if (hasComma) {
            if (hasSuffix) {
                String afterComma = raw.substring(raw.indexOf(',') + 1);
                if (afterComma.length() <= 2) {
                    return raw.replace(',', '.');
                }
            }
            return raw.replace(",", "");
        }

        if (hasDot && hasSuffix) {
            String afterDot = raw.substring(raw.indexOf('.') + 1);
            if (afterDot.length() == 3 && raw.indexOf('.') == raw.lastIndexOf('.')) {
                return raw.replace(".", "");
            }
        }

        return raw;
    }

    public static AlertTier resolveTier(double amount) {
        ConfigManager.ModConfig cfg = ConfigManager.get();
        if (amount >= cfg.tier5Min) {
            return AlertTier.TIER_5_10B_PLUS;
        }
        if (amount >= cfg.tier4Min) {
            return AlertTier.TIER_4_1B;
        }
        if (amount >= cfg.tier3Min) {
            return AlertTier.TIER_3_100M;
        }
        if (amount >= cfg.tier2Min) {
            return AlertTier.TIER_2_10M;
        }
        return AlertTier.TIER_1_1M;
    }

    public static String formatCompactAmount(double amount) {
        double abs = Math.abs(amount);
        String sign = amount < 0 ? "-" : "+";
        if (abs >= 1_000_000_000_000.0) {
            return sign + "$" + trimZeros(abs / 1_000_000_000_000.0) + "T";
        }
        if (abs >= 1_000_000_000.0) {
            return sign + "$" + trimZeros(abs / 1_000_000_000.0) + "B";
        }
        if (abs >= 1_000_000.0) {
            return sign + "$" + trimZeros(abs / 1_000_000.0) + "M";
        }
        if (abs >= 1_000.0) {
            return sign + "$" + trimZeros(abs / 1_000.0) + "K";
        }
        return sign + "$" + trimZeros(abs);
    }

    private static String trimZeros(double value) {
        if (Math.abs(value - Math.round(value)) < 0.005) {
            return Long.toString(Math.round(value));
        }
        String formatted = String.format(Locale.US, "%.2f", value);
        while (formatted.contains(".") && (formatted.endsWith("0") || formatted.endsWith("."))) {
            formatted = formatted.substring(0, formatted.length() - 1);
        }
        return formatted;
    }
}

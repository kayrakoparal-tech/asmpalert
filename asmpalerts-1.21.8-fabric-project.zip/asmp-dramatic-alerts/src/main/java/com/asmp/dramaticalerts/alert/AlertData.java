package com.asmp.dramaticalerts.alert;

import com.asmp.dramaticalerts.util.AmountParser;

public class AlertData {
    public final String senderName;
    public final double amount;
    public final AmountParser.AlertTier tier;
    public final float durationSeconds;
    public final long createdAtNanos;

    public AlertData(String senderName, double amount, AmountParser.AlertTier tier, float durationSeconds) {
        this.senderName = (senderName == null || senderName.isBlank()) ? "Bilinmeyen" : senderName.trim();
        this.amount = Math.max(0.0, amount);
        this.tier = tier != null ? tier : AmountParser.resolveTier(this.amount);
        this.durationSeconds = Math.max(2.5f, durationSeconds);
        this.createdAtNanos = System.nanoTime();
    }
}

package com.asmp.dramaticalerts;

import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.listener.AlertCommand;
import com.asmp.dramaticalerts.listener.ChatListener;
import com.asmp.dramaticalerts.render.AlertHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class AsmpAlertsClient implements ClientModInitializer {
    public static final String MOD_ID = "asmpalerts";

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        ChatListener.reloadPatterns();

        ClientTickEvents.END_CLIENT_TICK.register(client -> AlertManager.tick());
        HudRenderCallback.EVENT.register(AlertHudRenderer::onHudRender);

        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) ->
                ChatListener.onMessageReceived(message, false));

        ClientReceiveMessageEvents.GAME.register((message, overlay) ->
                ChatListener.onMessageReceived(message, overlay));

        ClientCommandRegistrationCallback.EVENT.register(AlertCommand::register);
    }
}

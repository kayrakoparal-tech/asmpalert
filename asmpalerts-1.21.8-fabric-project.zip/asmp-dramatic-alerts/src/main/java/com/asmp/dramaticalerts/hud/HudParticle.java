package com.asmp.dramaticalerts.hud;

public class HudParticle {
    public enum ParticleKind {
        FIREWORK_SPARK,
        METEOR_HEAD,
        METEOR_TRAIL,
        CONFETTI_GOLD,
        STAR_BURST
    }

    public ParticleKind kind;
    public float x;
    public float y;
    public float vx;
    public float vy;
    public float gravity;
    public float drag;
    public float size;
    public float rotation;
    public float angularVelocity;
    public int argbColor;
    public float ageSeconds;
    public float maxAgeSeconds;
    public boolean active;

    public void reset(
            ParticleKind kind,
            float x,
            float y,
            float vx,
            float vy,
            float gravity,
            float drag,
            float size,
            float rotation,
            float angularVelocity,
            int argbColor,
            float maxAgeSeconds
    ) {
        this.kind = kind;
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.gravity = gravity;
        this.drag = drag;
        this.size = size;
        this.rotation = rotation;
        this.angularVelocity = angularVelocity;
        this.argbColor = argbColor;
        this.ageSeconds = 0.0f;
        this.maxAgeSeconds = Math.max(0.05f, maxAgeSeconds);
        this.active = true;
    }

    public void update(float dt) {
        if (!active) {
            return;
        }
        ageSeconds += dt;
        if (ageSeconds >= maxAgeSeconds) {
            active = false;
            return;
        }

        float damping = Math.max(0.0f, 1.0f - drag * dt);
        vx *= damping;
        vy = vy * damping + gravity * dt;

        x += vx * dt;
        y += vy * dt;
        rotation += angularVelocity * dt;
    }

    public float getLifeProgress() {
        return Math.min(1.0f, Math.max(0.0f, ageSeconds / maxAgeSeconds));
    }

    public float getAlphaFactor() {
        float p = getLifeProgress();
        if (p < 0.12f) {
            return p / 0.12f;
        }
        return Math.max(0.0f, 1.0f - ((p - 0.12f) / 0.88f));
    }
}

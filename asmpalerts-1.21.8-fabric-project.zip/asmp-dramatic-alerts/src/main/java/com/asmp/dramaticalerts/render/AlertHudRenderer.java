package com.asmp.dramaticalerts.render;

import com.asmp.dramaticalerts.alert.AlertData;
import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.hud.HudParticle;
import com.asmp.dramaticalerts.util.AmountParser;
import com.asmp.dramaticalerts.util.EasingUtils;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class AlertHudRenderer {
    private static final int MAX_PARTICLES = 260;
    private static final List<HudParticle> PARTICLES = new ArrayList<>(MAX_PARTICLES);
    private static final Random RNG = new Random();

    private static float rayAngle = 0.0f;
    private static float meteorSpawnTimer = 0.0f;
    private static float confettiSpawnTimer = 0.0f;
    private static float shakeOffsetX = 0.0f;
    private static float shakeOffsetY = 0.0f;
    private static float shakeRemaining = 0.0f;
    private static float shakeStrength = 0.0f;

    static {
        for (int i = 0; i < MAX_PARTICLES; i++) {
            PARTICLES.add(new HudParticle());
        }
    }

    public static void resetEffects() {
        for (HudParticle p : PARTICLES) {
            p.active = false;
        }
        shakeRemaining = 0.0f;
        shakeOffsetX = 0.0f;
        shakeOffsetY = 0.0f;
    }

    public static void triggerInitialBurst(AlertData alert) {
        MinecraftClient client = MinecraftClient.getInstance();
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        float centerX = screenW * 0.5f;
        float centerY = Math.min(screenH * 0.24f, 115.0f);

        float mult = ConfigManager.get().particleMultiplier;
        int tier = alert.tier.level;

        int fireworkCount = Math.round((28 + tier * 14) * mult);
        spawnFireworkBurst(centerX - 85f, centerY, fireworkCount / 2);
        spawnFireworkBurst(centerX + 85f, centerY, fireworkCount / 2);

        if (tier >= 2) {
            int meteorCount = tier >= 5 ? 4 : (tier >= 4 ? 2 : 1);
            for (int i = 0; i < meteorCount; i++) {
                spawnMeteor(screenW, centerX, centerY);
            }
            addShake(0.35f + tier * 0.08f, (2.2f + tier * 1.1f));
        }

        if (tier >= 3) {
            spawnStarBurst(centerX, centerY, Math.round(24 * tier * 0.5f * mult));
        }

        meteorSpawnTimer = 0.35f;
        confettiSpawnTimer = 0.05f;
    }

    public static void updateActiveAlert(AlertData alert, float elapsed, float dt) {
        MinecraftClient client = MinecraftClient.getInstance();
        int screenW = Math.max(1, client.getWindow().getScaledWidth());
        int screenH = Math.max(1, client.getWindow().getScaledHeight());
        float centerX = screenW * 0.5f;
        float centerY = Math.min(screenH * 0.24f, 115.0f);

        rayAngle += dt * (0.45f + alert.tier.level * 0.14f);

        float remaining = alert.durationSeconds - elapsed;
        float mult = ConfigManager.get().particleMultiplier;
        int tier = alert.tier.level;

        if (remaining > 0.7f) {
            confettiSpawnTimer -= dt;
            float confettiInterval = Math.max(0.025f, 0.11f - tier * 0.015f);
            if (confettiSpawnTimer <= 0.0f) {
                confettiSpawnTimer = confettiInterval;
                int batch = Math.round((2 + tier * 2) * mult);
                for (int i = 0; i < batch; i++) {
                    spawnConfetti(screenW, centerX, centerY, tier);
                }
            }

            if (tier >= 2) {
                meteorSpawnTimer -= dt;
                float meteorInterval = tier >= 5 ? 0.55f : (tier >= 4 ? 0.85f : 1.35f);
                if (meteorSpawnTimer <= 0.0f) {
                    meteorSpawnTimer = meteorInterval;
                    spawnMeteor(screenW, centerX, centerY);
                    if (elapsed > 0.45f) {
                        addShake(0.22f, 1.5f + tier * 0.7f);
                    }
                }
            }
        }

        updateParticlesAndShake(dt);
    }

    public static void updateAmbientParticles(float dt) {
        updateParticlesAndShake(dt);
    }

    private static void updateParticlesAndShake(float dt) {
        for (HudParticle p : PARTICLES) {
            if (!p.active) {
                continue;
            }
            p.update(dt);
            if (p.active && p.kind == HudParticle.ParticleKind.METEOR_HEAD) {
                HudParticle trail = acquireParticle();
                if (trail != null) {
                    int trailColor = RNG.nextBoolean() ? 0xFFFF9A1F : 0xFFFFE066;
                    trail.reset(
                            HudParticle.ParticleKind.METEOR_TRAIL,
                            p.x + (RNG.nextFloat() - 0.5f) * 6f,
                            p.y + (RNG.nextFloat() - 0.5f) * 6f,
                            -p.vx * 0.12f + (RNG.nextFloat() - 0.5f) * 25f,
                            -p.vy * 0.12f + (RNG.nextFloat() - 0.5f) * 25f,
                            40.0f,
                            2.5f,
                            Math.max(2.0f, p.size * 0.55f),
                            0.0f,
                            0.0f,
                            trailColor,
                            0.28f
                    );
                }
            }
        }

        ConfigManager.ModConfig cfg = ConfigManager.get();
        if (shakeRemaining > 0.0f && cfg.enableScreenShake && cfg.shakeIntensity > 0.0f) {
            shakeRemaining -= dt;
            float decay = EasingUtils.clamp01(shakeRemaining / 0.45f);
            float mag = shakeStrength * cfg.shakeIntensity * decay;
            shakeOffsetX = (RNG.nextFloat() * 2.0f - 1.0f) * mag;
            shakeOffsetY = (RNG.nextFloat() * 2.0f - 1.0f) * mag;
        } else {
            shakeOffsetX = 0.0f;
            shakeOffsetY = 0.0f;
        }
    }

    public static void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        AlertData alert = AlertManager.getCurrentAlert();
        boolean hasActiveAlert = alert != null;
        boolean hasAnyParticle = hasActiveParticles();

        if (!hasActiveAlert && !hasAnyParticle) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer textRenderer = client.textRenderer;
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        float elapsed = AlertManager.getCurrentElapsedSeconds();
        float duration = hasActiveAlert ? alert.durationSeconds : 1.0f;

        float enterT = hasActiveAlert ? EasingUtils.easeOutBack(EasingUtils.clamp01(elapsed / 0.35f)) : 0.0f;
        float exitAlpha = hasActiveAlert
                ? EasingUtils.easeInOutQuad(EasingUtils.clamp01((duration - elapsed) / 0.55f))
                : 0.0f;
        float masterAlpha = hasActiveAlert ? Math.min(EasingUtils.clamp01(elapsed / 0.22f), exitAlpha) : 0.0f;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(shakeOffsetX, shakeOffsetY);

        float centerX = screenW * 0.5f;
        float centerY = Math.min(screenH * 0.24f, 115.0f);

        if (hasActiveAlert && masterAlpha > 0.01f) {
            int tier = alert.tier.level;

            if (tier >= 4) {
                int vigAlpha = Math.round(68 * masterAlpha);
                int vigColor = (vigAlpha << 24) | 0x2A083B;
                context.fill(0, 0, screenW, 18, vigColor);
                context.fill(0, screenH - 18, screenW, screenH, vigColor);
                context.fill(0, 18, 18, screenH - 18, vigColor);
                context.fill(screenW - 18, 18, screenW, screenH - 18, vigColor);
            }

            if (tier >= 3) {
                renderSunburstRays(context, centerX, centerY + 14f, tier, masterAlpha);
            }

            if (elapsed < 0.75f) {
                renderShockRings(context, centerX, centerY + 14f, elapsed, tier, masterAlpha);
            }

            renderAlertCard(context, textRenderer, alert, elapsed, enterT, masterAlpha, centerX, centerY);
        }

        renderParticles(context);

        context.getMatrices().popMatrix();
    }

    private static void renderSunburstRays(DrawContext context, float cx, float cy, int tier, float masterAlpha) {
        int rayCount = tier >= 5 ? 16 : 10;
        int maxLen = tier >= 5 ? 150 : 105;
        int baseAlpha = Math.round((tier >= 5 ? 46 : 30) * masterAlpha);
        if (baseAlpha <= 0) {
            return;
        }

        int rayColor = (baseAlpha << 24) | (tier >= 4 ? 0xFFD24D : 0xC864FF);

        for (int i = 0; i < rayCount; i++) {
            double angle = rayAngle + (i * (Math.PI * 2.0 / rayCount));
            float dx = (float) Math.cos(angle);
            float dy = (float) Math.sin(angle);
            int steps = 10;
            for (int s = 2; s <= steps; s++) {
                float dist = (maxLen / (float) steps) * s;
                float thickness = Math.max(1.5f, (1.0f - (s / (float) (steps + 2))) * (tier >= 5 ? 6.0f : 4.0f));
                int px = Math.round(cx + dx * dist - thickness * 0.5f);
                int py = Math.round(cy + dy * dist - thickness * 0.5f);
                context.fill(px, py, Math.round(px + thickness), Math.round(py + thickness), rayColor);
            }
        }
    }

    private static void renderShockRings(DrawContext context, float cx, float cy, float elapsed, int tier, float masterAlpha) {
        int ringCount = tier >= 4 ? 2 : 1;
        for (int r = 0; r < ringCount; r++) {
            float t = EasingUtils.clamp01((elapsed - r * 0.14f) / 0.55f);
            if (t <= 0.0f || t >= 1.0f) {
                continue;
            }
            float eased = EasingUtils.easeOutCubic(t);
            float radius = 14.0f + eased * (85.0f + tier * 18.0f);
            int alpha = Math.round((1.0f - t) * 140.0f * masterAlpha);
            if (alpha <= 0) {
                continue;
            }
            int color = (alpha << 24) | (r == 0 ? 0xFFD700 : 0xFF7B00);
            int segments = 28;
            for (int i = 0; i < segments; i++) {
                double a = (i * Math.PI * 2.0) / segments;
                int x1 = Math.round(cx + (float) Math.cos(a) * radius);
                int y1 = Math.round(cy + (float) Math.sin(a) * radius);
                context.fill(x1 - 1, y1 - 1, x1 + 2, y1 + 2, color);
            }
        }
    }

    private static void renderAlertCard(
            DrawContext context,
            TextRenderer textRenderer,
            AlertData alert,
            float elapsed,
            float enterT,
            float masterAlpha,
            float centerX,
            float centerY
    ) {
        int cardW = 248;
        int cardH = 54;

        float scale = EasingUtils.lerp(0.78f, 1.0f, EasingUtils.clamp01(enterT));
        float yOffset = EasingUtils.lerp(-24.0f, 0.0f, EasingUtils.easeOutCubic(EasingUtils.clamp01(elapsed / 0.3f)));

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(centerX, centerY + yOffset);
        context.getMatrices().scale(scale, scale);

        int left = -cardW / 2;
        int top = -cardH / 2;
        int right = cardW / 2;
        int bottom = cardH / 2;

        int bgAlpha = Math.round(215 * masterAlpha);
        int borderAlpha = Math.round(240 * masterAlpha);

        int bgColor = (bgAlpha << 24) | 0x12121C;
        int borderColor = (borderAlpha << 24) | resolveTierAccentHex(alert.tier.level);

        context.fill(left, top, right, bottom, bgColor);
        context.fill(left - 2, top - 2, right + 2, top, borderColor);
        context.fill(left - 2, bottom, right + 2, bottom + 2, borderColor);
        context.fill(left - 2, top, left, bottom, borderColor);
        context.fill(right, top, right + 2, bottom, borderColor);

        int headSize = 32;
        int headX = left + 10;
        int headY = top + (cardH - headSize) / 2;
        drawPlayerHead(context, alert.senderName, headX, headY, headSize);

        int textLeft = headX + headSize + 10;
        int textCenterX = (textLeft + right - 6) / 2;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(textCenterX, top + 11);
        context.getMatrices().scale(0.82f, 0.82f);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(alert.tier.badgeText), 0, 0, 0xFFFFFF);
        context.getMatrices().popMatrix();

        double rollProgress = EasingUtils.easeOutCubic(EasingUtils.clamp01(elapsed / 0.85f));
        double currentDisplayedAmount = alert.amount * rollProgress;
        String amountText = AmountParser.formatCompactAmount(currentDisplayedAmount);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(textCenterX, top + 27);
        context.getMatrices().scale(1.38f, 1.38f);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("§6§l" + amountText), 0, 0, 0xFFD700);
        context.getMatrices().popMatrix();

        String subLine = "§f" + alert.senderName + " §7sana ödeme gönderdi!";
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(textCenterX, top + 43);
        context.getMatrices().scale(0.85f, 0.85f);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(subLine), 0, 0, 0xE6E6E6);
        context.getMatrices().popMatrix();

        context.getMatrices().popMatrix();
    }

    private static void drawPlayerHead(DrawContext context, String playerName, int x, int y, int size) {
        MinecraftClient client = MinecraftClient.getInstance();
        Identifier skinTexture = DefaultSkinHelper.getTexture(UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes()));

        if (client.getNetworkHandler() != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(playerName);
            if (entry != null && entry.getSkinTextures() != null) {
                skinTexture = entry.getSkinTextures().texture();
            } else {
                GameProfile profile = client.getNetworkHandler().getPlayerList().stream()
                        .map(PlayerListEntry::getProfile)
                        .filter(p -> p.getName().equalsIgnoreCase(playerName))
                        .findFirst()
                        .orElse(null);
                if (profile != null) {
                    skinTexture = DefaultSkinHelper.getTexture(profile.getId());
                }
            }
        }

        PlayerSkinDrawer.draw(context, skinTexture, x, y, size, true, false);
    }

    private static void renderParticles(DrawContext context) {
        for (HudParticle p : PARTICLES) {
            if (!p.active) {
                continue;
            }
            float alphaFactor = p.getAlphaFactor();
            int baseAlpha = (p.argbColor >>> 24) & 0xFF;
            int finalAlpha = Math.max(0, Math.min(255, Math.round(baseAlpha * alphaFactor)));
            if (finalAlpha <= 2) {
                continue;
            }

            int rgb = p.argbColor & 0x00FFFFFF;
            int finalColor = (finalAlpha << 24) | rgb;

            float half = p.size * 0.5f;
            int x1 = Math.round(p.x - half);
            int y1 = Math.round(p.y - half);
            int x2 = Math.max(x1 + 1, Math.round(p.x + half));
            int y2 = Math.max(y1 + 1, Math.round(p.y + half));

            context.fill(x1, y1, x2, y2, finalColor);
        }
    }

    private static void spawnFireworkBurst(float originX, float originY, int count) {
        int[] palette = {0xFFFF5555, 0xFFFFAA00, 0xFFFFFF55, 0xFF55FF55, 0xFF55FFFF, 0xFFFF55FF};
        for (int i = 0; i < count; i++) {
            HudParticle p = acquireParticle();
            if (p == null) return;
            double angle = RNG.nextDouble() * Math.PI * 2.0;
            float speed = 45.0f + RNG.nextFloat() * 125.0f;
            float vx = (float) Math.cos(angle) * speed;
            float vy = (float) Math.sin(angle) * speed - 35.0f;
            int color = palette[RNG.nextInt(palette.length)];
            p.reset(
                    HudParticle.ParticleKind.FIREWORK_SPARK,
                    originX,
                    originY,
                    vx,
                    vy,
                    145.0f,
                    1.6f,
                    2.5f + RNG.nextFloat() * 2.5f,
                    0.0f,
                    0.0f,
                    color,
                    0.65f + RNG.nextFloat() * 0.55f
            );
        }
    }

    private static void spawnMeteor(int screenW, float targetCenterX, float targetCenterY) {
        HudParticle p = acquireParticle();
        if (p == null) return;

        float startX = targetCenterX + (RNG.nextFloat() - 0.5f) * Math.min(screenW * 0.55f, 260.0f) + 95.0f;
        float startY = -12.0f;
        float dx = (targetCenterX + (RNG.nextFloat() - 0.5f) * 140.0f) - startX;
        float dy = (targetCenterY + 20.0f) - startY;
        float flightTime = 0.42f;

        p.reset(
                HudParticle.ParticleKind.METEOR_HEAD,
                startX,
                startY,
                dx / flightTime,
                dy / flightTime,
                0.0f,
                0.0f,
                6.5f + RNG.nextFloat() * 2.5f,
                0.0f,
                0.0f,
                0xFFFF5E1A,
                flightTime
        );
    }

    private static void spawnConfetti(int screenW, float centerX, float centerY, int tier) {
        HudParticle p = acquireParticle();
        if (p == null) return;

        int[] goldPalette = {0xFFFFD700, 0xFFFFA500, 0xFFFFF176, 0xFF40E0D0, 0xFFE040FB};
        float x = centerX + (RNG.nextFloat() - 0.5f) * Math.min(screenW * 0.7f, 340.0f);
        float y = centerY + (RNG.nextFloat() - 0.5f) * 32.0f;
        float vx = (RNG.nextFloat() - 0.5f) * (50.0f + tier * 18.0f);
        float vy = -30.0f - RNG.nextFloat() * 65.0f;

        p.reset(
                HudParticle.ParticleKind.CONFETTI_GOLD,
                x,
                y,
                vx,
                vy,
                95.0f + tier * 15.0f,
                1.1f,
                3.0f + RNG.nextFloat() * 3.0f,
                RNG.nextFloat() * 6.28f,
                (RNG.nextFloat() - 0.5f) * 8.0f,
                goldPalette[RNG.nextInt(goldPalette.length)],
                0.9f + RNG.nextFloat() * 0.8f
        );
    }

    private static void spawnStarBurst(float cx, float cy, int count) {
        for (int i = 0; i < count; i++) {
            HudParticle p = acquireParticle();
            if (p == null) return;
            double angle = RNG.nextDouble() * Math.PI * 2.0;
            float speed = 30.0f + RNG.nextFloat() * 95.0f;
            p.reset(
                    HudParticle.ParticleKind.STAR_BURST,
                    cx,
                    cy + 14f,
                    (float) Math.cos(angle) * speed,
                    (float) Math.sin(angle) * speed,
                    35.0f,
                    2.2f,
                    2.2f + RNG.nextFloat() * 2.2f,
                    0.0f,
                    0.0f,
                    0xFFFFE57F,
                    0.6f + RNG.nextFloat() * 0.5f
            );
        }
    }

    private static void addShake(float duration, float strength) {
        shakeRemaining = Math.max(shakeRemaining, duration);
        shakeStrength = Math.max(shakeStrength, strength);
    }

    private static boolean hasActiveParticles() {
        for (HudParticle p : PARTICLES) {
            if (p.active) {
                return true;
            }
        }
        return false;
    }

    private static HudParticle acquireParticle() {
        for (HudParticle p : PARTICLES) {
            if (!p.active) {
                return p;
            }
        }
        HudParticle oldest = PARTICLES.get(0);
        for (HudParticle p : PARTICLES) {
            if (p.ageSeconds > oldest.ageSeconds) {
                oldest = p;
            }
        }
        return oldest;
    }

    private static int resolveTierAccentHex(int tierLevel) {
        return switch (tierLevel) {
            case 1 -> 0xFFF5C518;
            case 2 -> 0xFFFF7A00;
            case 3 -> 0xFFD946EF;
            case 4 -> 0xFFEF4444;
            default -> 0xFFFFD700;
        };
    }
}

package com.asmp.dramaticalerts.util;

public final class EasingUtils {
    private EasingUtils() {
    }

    public static float clamp01(float t) {
        if (t < 0.0f) return 0.0f;
        if (t > 1.0f) return 1.0f;
        return t;
    }

    public static float easeOutCubic(float t) {
        float x = clamp01(t);
        float inv = 1.0f - x;
        return 1.0f - (inv * inv * inv);
    }

    public static float easeInOutQuad(float t) {
        float x = clamp01(t);
        return x < 0.5f
                ? 2.0f * x * x
                : 1.0f - (float) Math.pow(-2.0f * x + 2.0f, 2.0) / 2.0f;
    }

    public static float easeOutBack(float t) {
        float x = clamp01(t);
        final float c1 = 1.70158f;
        final float c3 = c1 + 1.0f;
        float xMinus1 = x - 1.0f;
        return 1.0f + c3 * (xMinus1 * xMinus1 * xMinus1) + c1 * (xMinus1 * xMinus1);
    }

    public static float lerp(float start, float end, float t) {
        return start + (end - start) * t;
    }

    public static double lerp(double start, double end, double t) {
        return start + (end - start) * t;
    }
}

package com.asmp.dramaticalerts.listener;

import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.util.AmountParser;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class ChatListener {
    private static List<Pattern> compiledPatterns = List.of();
    private static List<String> lastRawPatterns = List.of();

    public static void reloadPatterns() {
        List<String> rawList = ConfigManager.get().chatRegexPatterns;
        if (rawList == null || rawList.isEmpty()) {
            compiledPatterns = List.of();
            lastRawPatterns = List.of();
            return;
        }

        List<Pattern> result = new ArrayList<>(rawList.size());
        for (String raw : rawList) {
            if (raw == null || raw.isBlank()) {
                continue;
            }
            try {
                result.add(Pattern.compile(raw));
            } catch (PatternSyntaxException ignored) {
            }
        }
        compiledPatterns = List.copyOf(result);
        lastRawPatterns = List.copyOf(rawList);
    }

    private static void ensurePatternsUpToDate() {
        List<String> current = ConfigManager.get().chatRegexPatterns;
        if (current != null && !current.equals(lastRawPatterns)) {
            reloadPatterns();
        }
    }

    public static void onMessageReceived(Text message, boolean overlay) {
        if (message == null) {
            return;
        }
        ConfigManager.ModConfig cfg = ConfigManager.get();
        if (!cfg.enabled) {
            return;
        }

        ensurePatternsUpToDate();
        if (compiledPatterns.isEmpty()) {
            return;
        }

        String plain = stripLegacyColorCodes(message.getString()).trim();
        if (plain.isEmpty()) {
            return;
        }

        String targetName = cfg.targetPlayerName != null ? cfg.targetPlayerName.trim() : "Xhantos";
        String lowerPlain = plain.toLowerCase(Locale.ROOT);
        String lowerTarget = targetName.toLowerCase(Locale.ROOT);

        for (Pattern pattern : compiledPatterns) {
            Matcher matcher = pattern.matcher(plain);
            if (!matcher.find() || matcher.groupCount() < 2) {
                continue;
            }

            String senderCandidate = cleanSenderName(matcher.group(1));
            String amountRaw = matcher.group(2);
            double parsedAmount = AmountParser.parseAmount(amountRaw);
            if (parsedAmount <= 0.0) {
                continue;
            }

            boolean mentionsYouOrTarget = lowerPlain.contains("you")
                    || lowerPlain.contains("sana")
                    || (!lowerTarget.isEmpty() && lowerPlain.contains(lowerTarget));

            if (!mentionsYouOrTarget) {
                continue;
            }

            if (!lowerTarget.isEmpty() && senderCandidate.equalsIgnoreCase(targetName)) {
                continue;
            }

            if (parsedAmount >= cfg.minimumTriggerAmount) {
                AlertManager.enqueue(senderCandidate, parsedAmount);
                return;
            }
        }
    }

    private static String stripLegacyColorCodes(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        return input.replaceAll("§[0-9A-FK-ORa-fk-or]", "");
    }

    private static String cleanSenderName(String rawSender) {
        if (rawSender == null) {
            return "Bilinmeyen";
        }
        String cleaned = stripLegacyColorCodes(rawSender)
                .replaceAll("^[\[\(]+|[\]\)]+$", "")
                .trim();
        if (cleaned.contains(" ")) {
            String[] parts = cleaned.split("\s+");
            cleaned = parts[parts.length - 1];
        }
        return cleaned.isEmpty() ? "Bilinmeyen" : cleaned;
    }
}
